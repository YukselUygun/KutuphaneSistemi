package State;

public interface BookState {
    void state(Book book);
}

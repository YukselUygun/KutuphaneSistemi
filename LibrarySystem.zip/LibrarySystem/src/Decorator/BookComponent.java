package Decorator;

public interface BookComponent {
    void display();
}

package Observer;

public interface Observer {
    void update(String kitapAdi, String kitapDurumu);
}

package Strategy;

import java.util.List;
public interface SearchStrategy {
    List<String> search(String query);
}
